import { 
  type User, 
  type InsertUser, 
  type TrackingLink, 
  type InsertTrackingLink,
  type Visitor,
  type InsertVisitor,
  type CameraSnapshot,
  type InsertCameraSnapshot,
  users,
  trackingLinks,
  visitors,
  cameraSnapshots
} from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";
import { eq } from "drizzle-orm";
import { db } from "./db";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Tracking link operations
  createTrackingLink(userId: string, link: InsertTrackingLink): Promise<TrackingLink>;
  getTrackingLinksByUserId(userId: string): Promise<TrackingLink[]>;
  getTrackingLinkByTrackingId(trackingId: string): Promise<TrackingLink | undefined>;
  
  // Visitor operations
  createVisitor(visitor: InsertVisitor): Promise<Visitor>;
  getVisitorsByTrackingId(trackingId: string): Promise<Visitor[]>;
  getRecentVisitors(limit?: number): Promise<Visitor[]>;
  
  // Camera snapshot operations
  createCameraSnapshot(snapshot: InsertCameraSnapshot): Promise<CameraSnapshot>;
  getCameraSnapshotsByTrackingId(trackingId: string): Promise<CameraSnapshot[]>;
  getRecentCameraSnapshots(limit?: number): Promise<CameraSnapshot[]>;
  
  // Analytics
  getVisitorStats(userId: string): Promise<any>;
  getDeviceStats(userId: string): Promise<any>;
  getLocationStats(userId: string): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private trackingLinks: Map<string, TrackingLink>;
  private visitors: Map<string, Visitor>;
  private cameraSnapshots: Map<string, CameraSnapshot>;

  constructor() {
    this.users = new Map();
    this.trackingLinks = new Map();
    this.visitors = new Map();
    this.cameraSnapshots = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async createTrackingLink(userId: string, insertLink: InsertTrackingLink): Promise<TrackingLink> {
    const id = randomUUID();
    const trackingId = Math.random().toString(36).substring(2, 15);
    const link: TrackingLink = {
      id,
      userId,
      trackingId,
      originalUrl: insertLink.originalUrl,
      campaignName: insertLink.campaignName || null,
      trackLocation: insertLink.trackLocation ?? true,
      trackDevice: insertLink.trackDevice ?? true,
      trackCamera: insertLink.trackCamera ?? false,
      createdAt: new Date()
    };
    this.trackingLinks.set(id, link);
    return link;
  }

  async getTrackingLinksByUserId(userId: string): Promise<TrackingLink[]> {
    return Array.from(this.trackingLinks.values()).filter(link => link.userId === userId);
  }

  async getTrackingLinkByTrackingId(trackingId: string): Promise<TrackingLink | undefined> {
    return Array.from(this.trackingLinks.values()).find(link => link.trackingId === trackingId);
  }

  async createVisitor(insertVisitor: InsertVisitor): Promise<Visitor> {
    const id = randomUUID();
    const visitor: Visitor = {
      id,
      trackingId: insertVisitor.trackingId,
      ipAddress: insertVisitor.ipAddress || null,
      userAgent: insertVisitor.userAgent || null,
      deviceInfo: insertVisitor.deviceInfo || null,
      location: insertVisitor.location || null,
      browserInfo: insertVisitor.browserInfo || null,
      timestamp: new Date()
    };
    this.visitors.set(id, visitor);
    return visitor;
  }

  async getVisitorsByTrackingId(trackingId: string): Promise<Visitor[]> {
    return Array.from(this.visitors.values()).filter(visitor => visitor.trackingId === trackingId);
  }

  async getRecentVisitors(limit: number = 10): Promise<Visitor[]> {
    return Array.from(this.visitors.values())
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }

  async createCameraSnapshot(insertSnapshot: InsertCameraSnapshot): Promise<CameraSnapshot> {
    const id = randomUUID();
    const snapshot: CameraSnapshot = {
      id,
      trackingId: insertSnapshot.trackingId,
      imageData: insertSnapshot.imageData || null,
      deviceInfo: insertSnapshot.deviceInfo || null,
      timestamp: new Date()
    };
    this.cameraSnapshots.set(id, snapshot);
    return snapshot;
  }

  async getCameraSnapshotsByTrackingId(trackingId: string): Promise<CameraSnapshot[]> {
    return Array.from(this.cameraSnapshots.values()).filter(snapshot => snapshot.trackingId === trackingId);
  }

  async getRecentCameraSnapshots(limit: number = 10): Promise<CameraSnapshot[]> {
    return Array.from(this.cameraSnapshots.values())
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }

  async getVisitorStats(userId: string): Promise<any> {
    const userLinks = await this.getTrackingLinksByUserId(userId);
    const trackingIds = userLinks.map(link => link.trackingId);
    const visitors = Array.from(this.visitors.values()).filter(visitor => 
      trackingIds.includes(visitor.trackingId)
    );

    return {
      totalVisits: visitors.length,
      uniqueVisitors: new Set(visitors.map(v => v.ipAddress)).size,
      activeLinks: userLinks.length,
      snapshots: Array.from(this.cameraSnapshots.values()).filter(snapshot => 
        trackingIds.includes(snapshot.trackingId)
      ).length
    };
  }

  async getDeviceStats(userId: string): Promise<any> {
    const userLinks = await this.getTrackingLinksByUserId(userId);
    const trackingIds = userLinks.map(link => link.trackingId);
    const visitors = Array.from(this.visitors.values()).filter(visitor => 
      trackingIds.includes(visitor.trackingId)
    );

    const devices = visitors.map(v => v.deviceInfo as any).filter(Boolean);
    const browsers = visitors.map(v => v.browserInfo as any).filter(Boolean);

    return {
      devices,
      browsers,
      deviceTypes: devices.reduce((acc: any, device: any) => {
        const type = device.type || 'Unknown';
        acc[type] = (acc[type] || 0) + 1;
        return acc;
      }, {})
    };
  }

  async getLocationStats(userId: string): Promise<any> {
    const userLinks = await this.getTrackingLinksByUserId(userId);
    const trackingIds = userLinks.map(link => link.trackingId);
    const visitors = Array.from(this.visitors.values()).filter(visitor => 
      trackingIds.includes(visitor.trackingId)
    );

    const locations = visitors.map(v => v.location as any).filter(Boolean);
    
    return {
      locations,
      countries: locations.reduce((acc: any, location: any) => {
        const country = location.country || 'Unknown';
        acc[country] = (acc[country] || 0) + 1;
        return acc;
      }, {})
    };
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    
    const [user] = await db
      .insert(users)
      .values({
        id,
        email: insertUser.email,
        password: hashedPassword,
        fullName: insertUser.fullName,
        createdAt: new Date()
      })
      .returning();
    return user;
  }

  async createTrackingLink(userId: string, insertLink: InsertTrackingLink): Promise<TrackingLink> {
    const id = randomUUID();
    const trackingId = Math.random().toString(36).substring(2, 15);
    
    const [link] = await db
      .insert(trackingLinks)
      .values({
        id,
        userId,
        trackingId,
        originalUrl: insertLink.originalUrl,
        campaignName: insertLink.campaignName || null,
        trackLocation: insertLink.trackLocation ?? true,
        trackDevice: insertLink.trackDevice ?? true,
        trackCamera: insertLink.trackCamera ?? false,
        createdAt: new Date()
      })
      .returning();
    return link;
  }

  async getTrackingLinksByUserId(userId: string): Promise<TrackingLink[]> {
    return await db.select().from(trackingLinks).where(eq(trackingLinks.userId, userId));
  }

  async getTrackingLinkByTrackingId(trackingId: string): Promise<TrackingLink | undefined> {
    const [link] = await db.select().from(trackingLinks).where(eq(trackingLinks.trackingId, trackingId));
    return link || undefined;
  }

  async createVisitor(insertVisitor: InsertVisitor): Promise<Visitor> {
    const id = randomUUID();
    
    const [visitor] = await db
      .insert(visitors)
      .values({
        id,
        trackingId: insertVisitor.trackingId,
        ipAddress: insertVisitor.ipAddress || null,
        userAgent: insertVisitor.userAgent || null,
        deviceInfo: insertVisitor.deviceInfo || null,
        location: insertVisitor.location || null,
        browserInfo: insertVisitor.browserInfo || null,
        timestamp: new Date()
      })
      .returning();
    return visitor;
  }

  async getVisitorsByTrackingId(trackingId: string): Promise<Visitor[]> {
    return await db.select().from(visitors).where(eq(visitors.trackingId, trackingId));
  }

  async getRecentVisitors(limit: number = 10): Promise<Visitor[]> {
    return await db.select().from(visitors).limit(limit);
  }

  async createCameraSnapshot(insertSnapshot: InsertCameraSnapshot): Promise<CameraSnapshot> {
    const id = randomUUID();
    
    const [snapshot] = await db
      .insert(cameraSnapshots)
      .values({
        id,
        trackingId: insertSnapshot.trackingId,
        imageData: insertSnapshot.imageData || null,
        deviceInfo: insertSnapshot.deviceInfo || null,
        timestamp: new Date()
      })
      .returning();
    return snapshot;
  }

  async getCameraSnapshotsByTrackingId(trackingId: string): Promise<CameraSnapshot[]> {
    return await db.select().from(cameraSnapshots).where(eq(cameraSnapshots.trackingId, trackingId));
  }

  async getRecentCameraSnapshots(limit: number = 10): Promise<CameraSnapshot[]> {
    return await db.select().from(cameraSnapshots).limit(limit);
  }

  async getVisitorStats(userId: string): Promise<any> {
    const userLinks = await this.getTrackingLinksByUserId(userId);
    const trackingIds = userLinks.map(link => link.trackingId);
    
    if (trackingIds.length === 0) {
      return {
        totalVisits: 0,
        activeLinks: 0,
        uniqueVisitors: 0,
        snapshots: 0
      };
    }

    // This is a simplified implementation - in production you'd use proper SQL aggregations
    const allVisitors = await Promise.all(
      trackingIds.map(id => this.getVisitorsByTrackingId(id))
    );
    const flatVisitors = allVisitors.flat();
    
    const allSnapshots = await Promise.all(
      trackingIds.map(id => this.getCameraSnapshotsByTrackingId(id))
    );
    const flatSnapshots = allSnapshots.flat();

    return {
      totalVisits: flatVisitors.length,
      activeLinks: userLinks.length,
      uniqueVisitors: new Set(flatVisitors.map(v => v.ipAddress)).size,
      snapshots: flatSnapshots.length
    };
  }

  async getDeviceStats(userId: string): Promise<any> {
    const userLinks = await this.getTrackingLinksByUserId(userId);
    const trackingIds = userLinks.map(link => link.trackingId);
    
    if (trackingIds.length === 0) {
      return { deviceTypes: {}, browsers: {} };
    }

    const allVisitors = await Promise.all(
      trackingIds.map(id => this.getVisitorsByTrackingId(id))
    );
    const flatVisitors = allVisitors.flat();

    const deviceTypes: Record<string, number> = {};
    const browsers: Record<string, number> = {};

    flatVisitors.forEach(visitor => {
      if (visitor.deviceInfo) {
        const device = visitor.deviceInfo as any;
        const deviceType = device.type || 'unknown';
        deviceTypes[deviceType] = (deviceTypes[deviceType] || 0) + 1;
      }
      
      if (visitor.browserInfo) {
        const browser = visitor.browserInfo as any;
        const browserName = browser.name || 'unknown';
        browsers[browserName] = (browsers[browserName] || 0) + 1;
      }
    });

    return { deviceTypes, browsers };
  }

  async getLocationStats(userId: string): Promise<any> {
    const userLinks = await this.getTrackingLinksByUserId(userId);
    const trackingIds = userLinks.map(link => link.trackingId);
    
    if (trackingIds.length === 0) {
      return { locations: [], countries: {} };
    }

    const allVisitors = await Promise.all(
      trackingIds.map(id => this.getVisitorsByTrackingId(id))
    );
    const flatVisitors = allVisitors.flat();

    const locations = flatVisitors
      .filter(visitor => visitor.location)
      .map(visitor => visitor.location);

    const countries: Record<string, number> = {};
    locations.forEach(location => {
      if (location && typeof location === 'object') {
        const loc = location as any;
        const country = loc.country || 'unknown';
        countries[country] = (countries[country] || 0) + 1;
      }
    });

    return { locations, countries };
  }
}

export const storage = new DatabaseStorage();
