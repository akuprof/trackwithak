import { AuthModal } from "@/components/auth/auth-modal";

export default function Auth() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-slate-900">
      <AuthModal />
    </div>
  );
}
