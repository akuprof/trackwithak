import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/lib/auth';
import { Sidebar } from '@/components/dashboard/sidebar';
import { Header } from '@/components/dashboard/header';
import { DashboardSection } from '@/components/sections/dashboard-section';
import { CreateSection } from '@/components/sections/create-section';
import { AnalyticsSection } from '@/components/sections/analytics-section';
import { TrackingSection } from '@/components/sections/tracking-section';
import { DevicesSection } from '@/components/sections/devices-section';
import { SnapshotsSection } from '@/components/sections/snapshots-section';
import { useState } from 'react';

export default function Dashboard() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [activeSection, setActiveSection] = useState('dashboard');

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation('/auth');
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-slate-900">
        <div className="text-slate-300">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return <DashboardSection userId={user.id} />;
      case 'create':
        return <CreateSection userId={user.id} />;
      case 'analytics':
        return <AnalyticsSection userId={user.id} />;
      case 'tracking':
        return <TrackingSection userId={user.id} />;
      case 'devices':
        return <DevicesSection userId={user.id} />;
      case 'snapshots':
        return <SnapshotsSection userId={user.id} />;
      default:
        return <DashboardSection userId={user.id} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-50">
      <Sidebar activeSection={activeSection} setActiveSection={setActiveSection} user={user} />
      <div className="ml-64">
        <Header activeSection={activeSection} />
        {renderSection()}
      </div>
    </div>
  );
}
