import { Bell } from 'lucide-react';

interface HeaderProps {
  activeSection: string;
}

export function Header({ activeSection }: HeaderProps) {
  const getTitleAndSubtitle = (section: string) => {
    const titles = {
      dashboard: { title: 'Dashboard', subtitle: 'Monitor your tracking links and analytics' },
      create: { title: 'Create Link', subtitle: 'Generate new tracking links' },
      analytics: { title: 'Analytics', subtitle: 'Detailed performance metrics' },
      tracking: { title: 'Live Tracking', subtitle: 'Real-time location monitoring' },
      devices: { title: 'Devices', subtitle: 'Device information and browser details' },
      snapshots: { title: 'Snapshots', subtitle: 'Camera captures from visitors' },
    };
    return titles[section as keyof typeof titles] || titles.dashboard;
  };

  const { title, subtitle } = getTitleAndSubtitle(activeSection);

  return (
    <header className="surface border-b border-border px-8 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{title}</h1>
          <p className="text-slate-400 text-sm">{subtitle}</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-slate-800 px-3 py-2 rounded-lg">
            <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
            <span className="text-sm text-slate-300">Live</span>
          </div>
          <button className="p-2 text-slate-400 hover:text-slate-300 relative">
            <Bell size={20} />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full text-xs flex items-center justify-center text-white">
              3
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
