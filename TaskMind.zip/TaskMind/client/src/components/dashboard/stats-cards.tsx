import { Link, Eye, MapPin, Camera } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface StatsCardsProps {
  stats: {
    totalVisits: number;
    activeLinks: number;
    uniqueVisitors: number;
    snapshots: number;
  };
}

export function StatsCards({ stats }: StatsCardsProps) {
  const cards = [
    {
      title: 'Active Links',
      value: stats.activeLinks,
      change: '+12%',
      icon: Link,
      color: 'primary',
    },
    {
      title: 'Total Visits',
      value: stats.totalVisits,
      change: '+8%',
      icon: Eye,
      color: 'accent',
    },
    {
      title: 'Locations Tracked',
      value: stats.uniqueVisitors,
      change: '+23%',
      icon: MapPin,
      color: 'secondary',
    },
    {
      title: 'Snapshots',
      value: stats.snapshots,
      change: '+5%',
      icon: Camera,
      color: 'orange',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <Card key={card.title} className="surface border-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  card.color === 'primary' ? 'bg-primary/20' :
                  card.color === 'accent' ? 'bg-accent/20' :
                  card.color === 'secondary' ? 'bg-secondary/20' :
                  'bg-orange-500/20'
                }`}>
                  <Icon className={`text-xl ${
                    card.color === 'primary' ? 'text-primary' :
                    card.color === 'accent' ? 'text-accent' :
                    card.color === 'secondary' ? 'text-secondary' :
                    'text-orange-500'
                  }`} size={24} />
                </div>
                <span className="text-accent text-sm font-medium">{card.change}</span>
              </div>
              <h3 className="text-2xl font-bold mb-1">{card.value}</h3>
              <p className="text-slate-400 text-sm">{card.title}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
