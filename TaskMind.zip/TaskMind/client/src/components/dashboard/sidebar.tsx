import { User } from '@shared/schema';
import { useAuth } from '@/lib/auth';
import { Link, Eye, Plus, BarChart3, MapPin, Smartphone, Camera, LogOut } from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  user: User;
}

export function Sidebar({ activeSection, setActiveSection, user }: SidebarProps) {
  const { logout } = useAuth();

  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'create', label: 'Create Link', icon: Plus },
    { id: 'analytics', label: 'Analytics', icon: Eye },
    { id: 'tracking', label: 'Live Tracking', icon: MapPin },
    { id: 'devices', label: 'Devices', icon: Smartphone },
    { id: 'snapshots', label: 'Snapshots', icon: Camera },
  ];

  return (
    <div className="fixed left-0 top-0 h-full w-64 surface border-r border-border z-40">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Link className="text-white" size={16} />
          </div>
          <span className="text-xl font-bold">TrackDown</span>
        </div>
        
        <nav className="space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`nav-item w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  activeSection === item.id
                    ? 'active bg-slate-700 text-slate-50'
                    : 'text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 p-6">
        <div className="flex items-center space-x-3 p-3 bg-slate-800 rounded-lg">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-medium">
              {user.fullName?.split(' ').map(n => n[0]).join('') || 'U'}
            </span>
          </div>
          <div className="flex-1">
            <div className="text-sm font-medium">{user.fullName}</div>
            <div className="text-xs text-slate-400">{user.email}</div>
          </div>
          <button
            onClick={logout}
            className="text-slate-400 hover:text-slate-300"
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
