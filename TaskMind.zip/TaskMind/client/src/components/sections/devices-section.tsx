import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Smartphone, Monitor, Tablet } from 'lucide-react';

interface DevicesSectionProps {
  userId: string;
}

export function DevicesSection({ userId }: DevicesSectionProps) {
  const { data: recentVisitors } = useQuery({
    queryKey: ['/api/visitors/recent'],
  });

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType?.toLowerCase()) {
      case 'mobile':
        return <Smartphone className="text-slate-400" size={16} />;
      case 'tablet':
        return <Tablet className="text-slate-400" size={16} />;
      default:
        return <Monitor className="text-slate-400" size={16} />;
    }
  };

  return (
    <section className="p-8">
      <Card className="surface border-border">
        <CardHeader>
          <CardTitle>Device Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-medium text-slate-300">Visitor</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-300">Device</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-300">Browser</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-300">OS</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-300">IP Address</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-300">Last Seen</th>
                </tr>
              </thead>
              <tbody>
                {!recentVisitors || !Array.isArray(recentVisitors) || recentVisitors.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      No device data available
                    </td>
                  </tr>
                ) : (
                  recentVisitors.map((visitor: any, index: number) => (
                    <tr key={index} className="border-b border-slate-700">
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                            <span className="text-white text-xs">V{index + 1}</span>
                          </div>
                          <span className="font-medium">Visitor #{index + 1}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          {getDeviceIcon(visitor.deviceInfo?.type)}
                          <span>{visitor.deviceInfo?.name || 'Unknown Device'}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        {visitor.browserInfo?.name || 'Unknown'} {visitor.browserInfo?.version || ''}
                      </td>
                      <td className="py-4 px-4">
                        {visitor.deviceInfo?.os || 'Unknown OS'}
                      </td>
                      <td className="py-4 px-4">
                        {visitor.ipAddress || 'Unknown'}
                      </td>
                      <td className="py-4 px-4 text-slate-400">
                        {visitor.timestamp ? 
                          new Date(visitor.timestamp).toLocaleString() : 
                          'Unknown'
                        }
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
