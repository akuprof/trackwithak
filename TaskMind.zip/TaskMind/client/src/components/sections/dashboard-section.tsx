import { useQuery } from '@tanstack/react-query';
import { StatsCards } from '@/components/dashboard/stats-cards';
import { VisitsChart } from '@/components/charts/visits-chart';
import { GeoChart } from '@/components/charts/geo-chart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Link as LinkIcon, Camera } from 'lucide-react';
import { useWebSocket } from '@/hooks/use-websocket';
import { useState, useEffect } from 'react';

interface DashboardSectionProps {
  userId: string;
}

export function DashboardSection({ userId }: DashboardSectionProps) {
  const [realtimeVisitors, setRealtimeVisitors] = useState<any[]>([]);

  const { data: stats } = useQuery({
    queryKey: ['/api/analytics/stats', userId],
  });

  const { data: recentVisitors } = useQuery({
    queryKey: ['/api/visitors/recent'],
  });

  useWebSocket((message) => {
    if (message.type === 'new_visitor') {
      setRealtimeVisitors(prev => [message.data, ...prev.slice(0, 9)]);
    }
  });

  useEffect(() => {
    if (recentVisitors && Array.isArray(recentVisitors)) {
      setRealtimeVisitors(recentVisitors);
    }
  }, [recentVisitors]);

  if (!stats) {
    return (
      <div className="p-8">
        <div className="text-slate-300">Loading dashboard...</div>
      </div>
    );
  }

  const statsData = {
    totalVisits: stats.totalVisits || 0,
    activeLinks: stats.activeLinks || 0,
    uniqueVisitors: stats.uniqueVisitors || 0,
    snapshots: stats.snapshots || 0
  };

  return (
    <section className="p-8">
      <StatsCards stats={statsData} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="surface border-border">
          <CardHeader>
            <CardTitle>Visit Analytics</CardTitle>
          </CardHeader>
          <CardContent>
            <VisitsChart />
          </CardContent>
        </Card>

        <Card className="surface border-border">
          <CardHeader>
            <CardTitle>Geographic Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <GeoChart />
          </CardContent>
        </Card>
      </div>

      <Card className="surface border-border">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {realtimeVisitors.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                No recent activity to display
              </div>
            ) : (
              realtimeVisitors.map((visitor, index) => (
                <div key={index} className="flex items-center space-x-4 p-4 bg-slate-800 rounded-lg">
                  <div className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center">
                    <MapPin className="text-accent" size={16} />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">New visitor tracked</p>
                    <p className="text-sm text-slate-400">
                      {visitor.location?.city || 'Unknown location'} • {
                        visitor.timestamp ? new Date(visitor.timestamp).toLocaleString() : 'Just now'
                      }
                    </p>
                  </div>
                  <div className="text-sm text-slate-400">{visitor.ipAddress}</div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
