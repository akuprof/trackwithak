import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LiveMap } from '@/components/live-map';
import { MapPin, Globe, Clock } from 'lucide-react';

interface TrackingSectionProps {
  userId: string;
}

export function TrackingSection({ userId }: TrackingSectionProps) {
  const { data: recentVisitors } = useQuery({
    queryKey: ['/api/visitors/recent'],
  });

  const { data: locationStats } = useQuery({
    queryKey: ['/api/analytics/locations', userId],
  });

  return (
    <section className="p-8">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <Card className="surface border-border">
            <CardHeader>
              <CardTitle>Live Location Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <LiveMap locations={locationStats?.locations && Array.isArray(locationStats.locations) ? locationStats.locations : []} />
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="surface border-border">
            <CardHeader>
              <CardTitle>Active Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {!recentVisitors || !Array.isArray(recentVisitors) || recentVisitors.length === 0 ? (
                  <div className="text-center py-8 text-slate-400">
                    No active sessions
                  </div>
                ) : (
                  recentVisitors.slice(0, 5).map((visitor: any, index: number) => (
                    <div key={index} className="p-4 bg-slate-800 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">Visitor #{index + 1}</span>
                        <div className="flex items-center space-x-1">
                          <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
                          <span className="text-xs text-slate-400">
                            {visitor.timestamp ? 
                              `${Math.floor((Date.now() - new Date(visitor.timestamp).getTime()) / 60000)}m ago` : 
                              'Live'
                            }
                          </span>
                        </div>
                      </div>
                      <div className="text-sm text-slate-400 space-y-1">
                        <p className="flex items-center space-x-2">
                          <MapPin size={14} />
                          <span>{visitor.location?.city || 'Unknown location'}</span>
                        </p>
                        <p className="flex items-center space-x-2">
                          <Globe size={14} />
                          <span>{visitor.ipAddress || 'Unknown IP'}</span>
                        </p>
                        <p className="flex items-center space-x-2">
                          <Clock size={14} />
                          <span>
                            {visitor.timestamp ? 
                              new Date(visitor.timestamp).toLocaleTimeString() : 
                              'Just now'
                            }
                          </span>
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
