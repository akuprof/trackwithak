import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrafficChart } from '@/components/charts/traffic-chart';
import { BrowserChart } from '@/components/charts/browser-chart';

interface AnalyticsSectionProps {
  userId: string;
}

export function AnalyticsSection({ userId }: AnalyticsSectionProps) {
  const { data: deviceStats } = useQuery({
    queryKey: ['/api/analytics/devices', userId],
  });

  const { data: links } = useQuery({
    queryKey: ['/api/links', userId],
  });

  return (
    <section className="p-8">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <Card className="surface border-border mb-6">
            <CardHeader>
              <CardTitle>Traffic Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <TrafficChart />
            </CardContent>
          </Card>

          <Card className="surface border-border">
            <CardHeader>
              <CardTitle>Top Performing Links</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {!links || !Array.isArray(links) || links.length === 0 ? (
                  <div className="text-center py-8 text-slate-400">
                    No links found. Create your first tracking link!
                  </div>
                ) : (
                  links.map((link: any) => (
                    <div key={link.id} className="flex items-center justify-between p-4 bg-slate-800 rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium">{link.campaignName || 'Untitled Campaign'}</p>
                        <p className="text-sm text-slate-400">trackdown.app/c/{link.trackingId}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">0 visits</p>
                        <p className="text-sm text-slate-400">No data yet</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="surface border-border mb-6">
            <CardHeader>
              <CardTitle>Browser Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <BrowserChart />
            </CardContent>
          </Card>

          <Card className="surface border-border">
            <CardHeader>
              <CardTitle>Device Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {deviceStats?.deviceTypes && typeof deviceStats.deviceTypes === 'object' ? (
                  Object.entries(deviceStats.deviceTypes).map(([type, count]: [string, any]) => (
                    <div key={type}>
                      <div className="flex items-center justify-between">
                        <span className="text-sm capitalize">{type}</span>
                        <span className="text-sm font-medium">{count}</span>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-2 mt-1">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ 
                            width: `${deviceStats?.deviceTypes ? (count / Object.values(deviceStats.deviceTypes).reduce((a: any, b: any) => a + b, 0)) * 100 : 0}%` 
                          }}
                        />
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-slate-400">No device data available</div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
