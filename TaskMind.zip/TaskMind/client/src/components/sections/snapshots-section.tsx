import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Smartphone, Monitor, Tablet } from 'lucide-react';

interface SnapshotsSectionProps {
  userId: string;
}

export function SnapshotsSection({ userId }: SnapshotsSectionProps) {
  const { data: snapshots } = useQuery({
    queryKey: ['/api/snapshots/recent'],
  });

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType?.toLowerCase()) {
      case 'mobile':
        return <Smartphone size={14} />;
      case 'tablet':
        return <Tablet size={14} />;
      default:
        return <Monitor size={14} />;
    }
  };

  return (
    <section className="p-8">
      <Card className="surface border-border">
        <CardHeader>
          <CardTitle>Camera Snapshots</CardTitle>
        </CardHeader>
        <CardContent>
          {!snapshots || !Array.isArray(snapshots) || snapshots.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <div className="mb-4">No camera snapshots available</div>
              <p className="text-sm">Snapshots will appear here when visitors grant camera permissions</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {snapshots.map((snapshot: any, index: number) => (
                <div key={index} className="bg-slate-800 rounded-lg overflow-hidden">
                  <div className="aspect-video bg-slate-700 flex items-center justify-center">
                    {snapshot.imageData ? (
                      <img 
                        src={`data:image/png;base64,${snapshot.imageData}`} 
                        alt="Camera snapshot" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="text-slate-400 text-center">
                        <div className="text-2xl mb-2">📷</div>
                        <div className="text-sm">No image data</div>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Visitor #{index + 1}</h4>
                      <span className="text-xs text-slate-400">
                        {snapshot.timestamp ? 
                          new Date(snapshot.timestamp).toLocaleString() : 
                          'Unknown time'
                        }
                      </span>
                    </div>
                    <div className="text-sm text-slate-400">
                      <p className="flex items-center space-x-2 mb-1">
                        <MapPin size={14} />
                        <span>Location unknown</span>
                      </p>
                      <p className="flex items-center space-x-2">
                        {getDeviceIcon(snapshot.deviceInfo?.type)}
                        <span>{snapshot.deviceInfo?.name || 'Unknown Device'}</span>
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}
