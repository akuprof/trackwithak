import { useEffect, useRef } from 'react';

export function GeoChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const data = [
      { label: 'USA', value: 45, color: '#6366F1' },
      { label: 'Canada', value: 20, color: '#8B5CF6' },
      { label: 'UK', value: 15, color: '#10B981' },
      { label: 'Germany', value: 12, color: '#F59E0B' },
      { label: 'Others', value: 8, color: '#EF4444' },
    ];

    const total = data.reduce((sum, item) => sum + item.value, 0);
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 20;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    let currentAngle = -Math.PI / 2;

    data.forEach((item) => {
      const sliceAngle = (item.value / total) * 2 * Math.PI;
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
      ctx.closePath();
      ctx.fillStyle = item.color;
      ctx.fill();
      
      currentAngle += sliceAngle;
    });

    // Draw legend
    ctx.font = '12px Inter';
    data.forEach((item, index) => {
      const y = 20 + index * 20;
      ctx.fillStyle = item.color;
      ctx.fillRect(10, y - 8, 12, 12);
      ctx.fillStyle = '#CBD5E1';
      ctx.fillText(`${item.label} (${item.value}%)`, 30, y);
    });

  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      width={400} 
      height={200} 
      className="w-full h-auto"
    />
  );
}