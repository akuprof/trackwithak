import { useEffect, useRef } from 'react';

export function TrafficChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cloudflareData = [12, 19, 15, 17, 22, 18, 24];
    const webviewData = [8, 12, 10, 14, 16, 12, 18];
    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    const width = canvas.width;
    const height = canvas.height;
    const padding = 40;
    const barWidth = (width - 2 * padding) / (labels.length * 2 + 1);
    
    ctx.clearRect(0, 0, width, height);
    
    // Draw grid
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= 5; i++) {
      const y = padding + (i * (height - 2 * padding)) / 5;
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();
    }
    
    // Draw bars
    labels.forEach((label, index) => {
      const x = padding + (index * 2 + 1) * barWidth;
      
      // CloudFlare bars
      const cfHeight = (cloudflareData[index] / 30) * (height - 2 * padding);
      ctx.fillStyle = '#6366F1';
      ctx.fillRect(x, height - padding - cfHeight, barWidth * 0.8, cfHeight);
      
      // WebView bars
      const wvHeight = (webviewData[index] / 30) * (height - 2 * padding);
      ctx.fillStyle = '#8B5CF6';
      ctx.fillRect(x + barWidth * 0.8, height - padding - wvHeight, barWidth * 0.8, wvHeight);
    });
    
    // Draw labels
    ctx.fillStyle = '#CBD5E1';
    ctx.font = '12px Inter';
    ctx.textAlign = 'center';
    
    labels.forEach((label, index) => {
      const x = padding + (index * 2 + 1.4) * barWidth;
      ctx.fillText(label, x, height - 10);
    });
    
    // Draw legend
    ctx.fillStyle = '#6366F1';
    ctx.fillRect(width - 150, 20, 12, 12);
    ctx.fillStyle = '#CBD5E1';
    ctx.textAlign = 'left';
    ctx.fillText('CloudFlare', width - 130, 30);
    
    ctx.fillStyle = '#8B5CF6';
    ctx.fillRect(width - 150, 40, 12, 12);
    ctx.fillStyle = '#CBD5E1';
    ctx.fillText('WebView', width - 130, 50);
    
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      width={600} 
      height={300} 
      className="w-full h-auto"
    />
  );
}