# Deployment Guide for Google Cloud Run

This guide explains how to deploy TrackDown to Google Cloud Run.

## Prerequisites

1. **Google Cloud Account**: Create an account at [cloud.google.com](https://cloud.google.com)
2. **Google Cloud CLI**: Install from [cloud.google.com/sdk](https://cloud.google.com/sdk)
3. **Project Setup**: Create a new project in Google Cloud Console

## Quick Deployment Steps

### 1. Prepare Google Cloud
```bash
# Login to Google Cloud
gcloud auth login

# Set your project ID (replace with your actual project ID)
gcloud config set project YOUR_PROJECT_ID

# Enable required APIs
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com
```

### 2. Deploy with Cloud Build
```bash
# Build and deploy using Cloud Build
gcloud builds submit --config cloudbuild.yaml

# Or use the deployment script
chmod +x cloud-run-deploy.sh
./cloud-run-deploy.sh
```

### 3. Manual Deployment
If you prefer manual steps:

```bash
# Build the Docker image
docker build -t gcr.io/YOUR_PROJECT_ID/trackdown .

# Push to Container Registry
docker push gcr.io/YOUR_PROJECT_ID/trackdown

# Deploy to Cloud Run
gcloud run deploy trackdown \
  --image gcr.io/YOUR_PROJECT_ID/trackdown \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080
```

## Environment Variables

For production, you'll need to set these environment variables in Cloud Run:

1. **DATABASE_URL**: Your PostgreSQL connection string
2. **NODE_ENV**: Set to `production`
3. **SESSION_SECRET**: A secure random string for sessions

To set environment variables:
```bash
gcloud run services update trackdown \
  --set-env-vars DATABASE_URL="your-database-url" \
  --set-env-vars SESSION_SECRET="your-secret-key" \
  --region us-central1
```

## Database Setup

### Option 1: Google Cloud SQL (Recommended)
1. Create a PostgreSQL instance in Cloud SQL
2. Create a database named `trackdown`
3. Get the connection string and set it as DATABASE_URL

### Option 2: External Database (Neon, Railway, etc.)
1. Create a PostgreSQL database with your preferred provider
2. Use the connection string in the DATABASE_URL environment variable

## Custom Domain (Optional)

To use a custom domain:
1. Map your domain in Cloud Run console
2. Update DNS records as instructed
3. SSL certificates are automatically managed

## Monitoring and Logs

- **Logs**: View in Cloud Console > Cloud Run > trackdown > Logs
- **Metrics**: Monitor traffic, errors, and latency in the Metrics tab
- **Alerts**: Set up alerts for high error rates or downtime

## Cost Optimization

Cloud Run pricing:
- **Free tier**: 2 million requests per month
- **Pay per use**: Only charged when handling requests
- **Auto-scaling**: Scales to zero when not in use

## Troubleshooting

### Common Issues:

1. **Build Failures**: Check that all dependencies are in package.json
2. **Port Issues**: Ensure the app listens on PORT environment variable (8080)
3. **Database Connections**: Verify DATABASE_URL is correctly set
4. **WebSocket Issues**: Cloud Run supports WebSockets but may need configuration

### Getting Help:
- Check Cloud Run logs for error messages
- Verify environment variables are set correctly
- Test locally with production build first

## Security Considerations

1. **Environment Variables**: Store sensitive data in Secret Manager
2. **Authentication**: Configure IAM properly for production
3. **HTTPS**: Automatically enabled by Cloud Run
4. **CORS**: Configure for your domain in production

Your TrackDown application will be available at:
`https://trackdown-[region]-[project-id].a.run.app`