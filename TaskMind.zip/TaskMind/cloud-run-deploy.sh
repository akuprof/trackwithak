#!/bin/bash
# Google Cloud Run deployment script

# Build and deploy to Cloud Run
echo "Building and deploying TrackDown to Google Cloud Run..."

# Set your project ID
PROJECT_ID="your-project-id"
SERVICE_NAME="trackdown"
REGION="us-central1"

# Authenticate (run this first time only)
# gcloud auth login
# gcloud config set project $PROJECT_ID

# Enable required APIs
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com

# Build and deploy
gcloud builds submit --tag gcr.io/$PROJECT_ID/$SERVICE_NAME

# Deploy to Cloud Run
gcloud run deploy $SERVICE_NAME \
  --image gcr.io/$PROJECT_ID/$SERVICE_NAME \
  --platform managed \
  --region $REGION \
  --allow-unauthenticated \
  --port 8080 \
  --memory 512Mi \
  --cpu 1 \
  --concurrency 80 \
  --max-instances 10

echo "Deployment complete!"
echo "Your app will be available at: https://$SERVICE_NAME-$REGION-$PROJECT_ID.a.run.app"