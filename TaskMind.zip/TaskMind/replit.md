# TrackDown - URL Tracking and Analytics Platform

## Overview

TrackDown is a full-stack web application that provides URL tracking and analytics capabilities. The platform allows users to create tracking links, monitor visitor activity in real-time, capture device information, and optionally take camera snapshots. It features a modern React frontend with a Node.js/Express backend, PostgreSQL database with Drizzle ORM, and real-time capabilities through WebSockets.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **Real-time Communication**: WebSocket client for live updates

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints under `/api` prefix
- **Real-time**: WebSocket server for live visitor tracking
- **Authentication**: Custom session-based auth with bcrypt password hashing
- **Middleware**: Request logging, JSON parsing, CORS support

### Database Architecture
- **Database**: PostgreSQL with Drizzle ORM
- **Schema**: Four main tables (users, tracking_links, visitors, camera_snapshots)
- **Migrations**: Drizzle Kit for schema management
- **Connection**: Neon Database serverless PostgreSQL

## Key Components

### Core Entities
1. **Users**: Account management with email/password authentication
2. **Tracking Links**: Generated URLs with unique tracking IDs and campaign settings
3. **Visitors**: Captured visitor data including IP, device info, location, and browser details
4. **Camera Snapshots**: Optional camera captures with device metadata

### Frontend Components
- **Dashboard**: Multi-section interface with sidebar navigation
- **Analytics Charts**: Custom canvas-based visualizations for traffic, browser, and geo data
- **Live Map**: Placeholder for real-time location tracking visualization
- **Authentication**: Login/register modal with form validation

### Backend Services
- **Storage Layer**: Abstract interface with in-memory implementation (designed for database integration)
- **Route Handlers**: CRUD operations for all entities with proper validation
- **WebSocket Server**: Real-time broadcasting of visitor events

## Data Flow

### User Registration/Authentication
1. User submits registration form through React frontend
2. Backend validates data using Zod schemas
3. Password is hashed with bcrypt before storage
4. User session is maintained in localStorage
5. Protected routes check authentication status

### Link Creation and Tracking
1. User creates tracking link with original URL and settings
2. System generates unique tracking ID
3. Visitor accesses tracking link
4. Backend captures visitor data (IP, device, location)
5. Real-time updates broadcast via WebSocket
6. Analytics data aggregated for dashboard display

### Real-time Updates
1. WebSocket connection established on dashboard load
2. New visitor events trigger server-side broadcasts
3. Connected clients receive real-time visitor updates
4. Dashboard components update without page refresh

## External Dependencies

### UI and Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **shadcn/ui**: Pre-built component system

### Data and State Management
- **TanStack Query**: Server state management and caching
- **Drizzle ORM**: Type-safe database queries
- **Zod**: Runtime type validation and schema parsing

### Authentication and Security
- **bcrypt**: Password hashing
- **connect-pg-simple**: PostgreSQL session store

### Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Type safety across the stack
- **ESBuild**: Fast JavaScript bundling

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: ESBuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **Development**: `npm run dev` starts server with Vite middleware
- **Production**: `npm run build && npm start` for optimized deployment
- **Database URL**: Required environment variable for PostgreSQL connection

### Google Cloud Run Deployment
- **Docker**: Containerized application with Node.js 18 Alpine base
- **Port Configuration**: Uses PORT environment variable (defaults to 8080 for Cloud Run)
- **Auto-scaling**: Scales to zero when not in use, handles traffic spikes automatically
- **WebSocket Support**: Configured for real-time features with reconnection logic
- **Deployment Files**: Includes Dockerfile, cloudbuild.yaml, and deployment scripts

### Hosting Requirements
- Node.js runtime environment
- PostgreSQL database (Cloud SQL or external provider like Neon)
- WebSocket support for real-time features
- Static file serving for React frontend
- SSL/TLS certificates (automatically managed by Cloud Run)

### Recent Changes (January 2025)
- Added Google Cloud Run deployment configuration
- Fixed WebSocket connection issues with proper reconnection logic  
- Updated port configuration for Cloud Run compatibility (8080)
- Created comprehensive deployment documentation and scripts
- Enhanced production build process for containerized deployment
- **Integrated PostgreSQL database with Neon serverless**
- **Implemented DatabaseStorage replacing in-memory storage**
- **Added free deployment options documentation**
- **Optimized for free-tier hosting platforms**

### User Preferences
- Continue with free deployment plans and hosting options
- Focus on cost-effective solutions for production deployment
- **Using Google Cloud Run deployment at: https://trackwithak-623836997544.europe-west1.run.app**
- **Environment-based URL configuration for production vs development**

The application follows a modern full-stack architecture with clear separation of concerns, type safety throughout, and real-time capabilities for an engaging user experience. Now ready for production deployment on multiple platforms including free hosting options.