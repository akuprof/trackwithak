import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trackingLinks = pgTable("tracking_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  originalUrl: text("original_url").notNull(),
  trackingId: text("tracking_id").notNull().unique(),
  campaignName: text("campaign_name"),
  trackLocation: boolean("track_location").default(true),
  trackDevice: boolean("track_device").default(true),
  trackCamera: boolean("track_camera").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const visitors = pgTable("visitors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trackingId: text("tracking_id").references(() => trackingLinks.trackingId).notNull(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  deviceInfo: jsonb("device_info"),
  location: jsonb("location"),
  browserInfo: jsonb("browser_info"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const cameraSnapshots = pgTable("camera_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trackingId: text("tracking_id").references(() => trackingLinks.trackingId).notNull(),
  imageData: text("image_data"),
  deviceInfo: jsonb("device_info"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  fullName: true,
});

export const insertTrackingLinkSchema = createInsertSchema(trackingLinks).pick({
  originalUrl: true,
  campaignName: true,
  trackLocation: true,
  trackDevice: true,
  trackCamera: true,
});

export const insertVisitorSchema = createInsertSchema(visitors).pick({
  trackingId: true,
  ipAddress: true,
  userAgent: true,
  deviceInfo: true,
  location: true,
  browserInfo: true,
});

export const insertCameraSnapshotSchema = createInsertSchema(cameraSnapshots).pick({
  trackingId: true,
  imageData: true,
  deviceInfo: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type TrackingLink = typeof trackingLinks.$inferSelect;
export type InsertTrackingLink = z.infer<typeof insertTrackingLinkSchema>;
export type Visitor = typeof visitors.$inferSelect;
export type InsertVisitor = z.infer<typeof insertVisitorSchema>;
export type CameraSnapshot = typeof cameraSnapshots.$inferSelect;
export type InsertCameraSnapshot = z.infer<typeof insertCameraSnapshotSchema>;
