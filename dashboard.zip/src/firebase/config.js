import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Firebase configuration
// Note: In a production environment, these should be environment variables
const firebaseConfig = {
  apiKey: "YOUR_API_KEY", // Replace with actual API key when deploying
  authDomain: "url-tracker-app.firebaseapp.com",
  projectId: "url-tracker-app",
  storageBucket: "url-tracker-app.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890abcdef"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };