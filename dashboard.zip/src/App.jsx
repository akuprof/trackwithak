import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/layout/Header';
import Sidebar from './components/layout/Sidebar';
import { AuthProvider, useAuth } from './context/AuthContext';
import LandingPage from './components/landing/LandingPage';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Dashboard from './components/tracking/Dashboard';
import LinkGenerator from './components/tracking/LinkGenerator';
import LinkDetail from './components/tracking/LinkDetail';
import TrackHandler from './components/tracking/TrackHandler';
import Profile from './components/user/Profile';

// Protected route component
const ProtectedRoute = ({ children }) => {
  const { currentUser, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }
  
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
};

// App layout with header and sidebar for authenticated users
const AppLayout = ({ children }) => {
  const { currentUser } = useAuth();
  
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      <div className="flex flex-1">
        {currentUser && <Sidebar />}
        <main className={`flex-1 p-6 overflow-auto ${currentUser ? '' : 'bg-white'}`}>
          {children}
        </main>
      </div>
    </div>
  );
};

// Main App component
const App = () => {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Special route for tracking links - no header/sidebar */}
          <Route 
            path="/t/:trackingType/:trackingId" 
            element={<TrackHandler />} 
          />
          
          {/* Routes with app layout */}
          <Route 
            path="/" 
            element={
              <AppLayout>
                <LandingPage />
              </AppLayout>
            } 
          />
          
          <Route 
            path="/login" 
            element={
              <AppLayout>
                <Login />
              </AppLayout>
            } 
          />
          
          <Route 
            path="/register" 
            element={
              <AppLayout>
                <Register />
              </AppLayout>
            } 
          />
          
          {/* Protected routes */}
          <Route 
            path="/dashboard" 
            element={
              <ProtectedRoute>
                <AppLayout>
                  <Dashboard />
                </AppLayout>
              </ProtectedRoute>
            } 
          />
          
          <Route 
            path="/create" 
            element={
              <ProtectedRoute>
                <AppLayout>
                  <LinkGenerator />
                </AppLayout>
              </ProtectedRoute>
            } 
          />
          
          <Route 
            path="/links/:linkId" 
            element={
              <ProtectedRoute>
                <AppLayout>
                  <LinkDetail />
                </AppLayout>
              </ProtectedRoute>
            } 
          />
          
          <Route 
            path="/profile" 
            element={
              <ProtectedRoute>
                <AppLayout>
                  <Profile />
                </AppLayout>
              </ProtectedRoute>
            } 
          />
          
          {/* Catch-all route */}
          <Route 
            path="*" 
            element={
              <AppLayout>
                <div className="flex flex-col items-center justify-center min-h-[60vh]">
                  <h2 className="text-3xl font-bold text-gray-800 mb-4">Page Not Found</h2>
                  <p className="text-gray-600 mb-8">The page you are looking for doesn't exist or has been moved.</p>
                  <button 
                    onClick={() => window.history.back()}
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                  >
                    Go Back
                  </button>
                </div>
              </AppLayout>
            } 
          />
        </Routes>
      </Router>
    </AuthProvider>
  );
};

export default App;