import React, { useState } from 'react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { nanoid } from 'nanoid';
import { db } from '../../firebase/config';
import { useAuth } from '../../context/AuthContext';

const LinkGenerator = () => {
  const [originalUrl, setOriginalUrl] = useState('');
  const [trackingType, setTrackingType] = useState('cloudflare'); // Default tracking type
  const [generatedLink, setGeneratedLink] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  
  const { currentUser, userData, updateLinkCount } = useAuth();

  const generateTrackingLink = async (e) => {
    e.preventDefault();
    setError('');
    setGeneratedLink(null);
    setCopied(false);
    
    // Validate URL
    if (!isValidUrl(originalUrl)) {
      setError('Please enter a valid URL');
      return;
    }
    
    // Check if user has reached their link limit
    if (userData.linksCreated >= userData.linksLimit) {
      setError(`You've reached your limit of ${userData.linksLimit} links. Please upgrade your plan to create more.`);
      return;
    }
    
    setLoading(true);
    
    try {
      // Generate a unique tracking ID
      const trackingId = nanoid(8);
      
      // Store link in Firestore
      const linkRef = collection(db, 'links');
      await addDoc(linkRef, {
        originalUrl,
        trackingId,
        userId: currentUser.uid,
        createdAt: serverTimestamp(),
        trackingType,
        clickCount: 0
      });
      
      // Update user's link count
      await updateLinkCount(true);
      
      // Generate the tracking URL
      const baseUrl = window.location.origin;
      const trackingUrl = `${baseUrl}/track/${trackingType}/${trackingId}`;
      
      setGeneratedLink(trackingUrl);
    } catch (err) {
      console.error('Error generating link:', err);
      setError('Failed to generate link. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedLink)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
      })
      .catch(err => {
        console.error('Failed to copy:', err);
      });
  };
  
  // Helper function to validate URLs
  const isValidUrl = (string) => {
    try {
      const url = new URL(string);
      return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
      return false;
    }
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-2xl font-semibold text-gray-800 mb-6">Create Tracking Link</h1>
        
        {userData && (
          <div className="mb-6 p-4 bg-blue-50 rounded-md">
            <div className="flex justify-between items-center">
              <p className="text-blue-800">
                <span className="font-medium">Links Used:</span> {userData.linksCreated} of {userData.linksLimit}
              </p>
              <p className="text-sm text-blue-800">
                <span className="font-medium">Plan:</span> {userData.subscriptionTier}
              </p>
            </div>
          </div>
        )}
        
        {error && (
          <div className="mb-6 p-4 bg-red-50 rounded-md">
            <p className="text-red-800">{error}</p>
          </div>
        )}
        
        <form onSubmit={generateTrackingLink} className="space-y-6">
          <div>
            <label htmlFor="originalUrl" className="block text-sm font-medium text-gray-700 mb-1">
              URL to Track
            </label>
            <input
              id="originalUrl"
              type="url"
              placeholder="https://example.com"
              value={originalUrl}
              onChange={(e) => setOriginalUrl(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          
          <div>
            <label htmlFor="trackingType" className="block text-sm font-medium text-gray-700 mb-1">
              Tracking Method
            </label>
            <select
              id="trackingType"
              value={trackingType}
              onChange={(e) => setTrackingType(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="cloudflare">Standard Redirect (Fast &amp; Invisible)</option>
              <option value="webview">Custom View (Branded Redirect Page)</option>
            </select>
            <p className="mt-1 text-sm text-gray-500">
              {trackingType === 'cloudflare' 
                ? 'Instantly redirects visitors to your URL while tracking clicks.' 
                : 'Shows a brief loading page before redirecting. Good for branding.'}
            </p>
          </div>
          
          <div>
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:bg-blue-300"
            >
              {loading ? 'Generating Link...' : 'Generate Tracking Link'}
            </button>
          </div>
        </form>
        
        {generatedLink && (
          <div className="mt-8 p-4 bg-gray-50 rounded-md">
            <h2 className="text-lg font-medium text-gray-800 mb-2">Your Tracking Link</h2>
            <div className="flex">
              <input
                type="text"
                value={generatedLink}
                readOnly
                className="flex-1 px-4 py-2 border border-gray-300 rounded-l-md bg-gray-100 focus:outline-none"
              />
              <button
                onClick={copyToClipboard}
                className={`px-4 py-2 rounded-r-md focus:outline-none ${
                  copied
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                }`}
              >
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
            <div className="mt-4">
              <a 
                href={`/results/${generatedLink.split('/').pop()}`}
                className="text-blue-600 hover:underline"
              >
                Go to tracking results
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LinkGenerator;