import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { useAuth } from '../../context/AuthContext';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';

const LinkDetail = () => {
  const { linkId } = useParams();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [linkData, setLinkData] = useState(null);
  const [visits, setVisits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const fetchLinkData = async () => {
      try {
        if (!currentUser || !linkId) return;
        
        // First, get the link data
        const linksRef = collection(db, 'links');
        const q = query(linksRef, where('trackingId', '==', linkId));
        const querySnapshot = await getDocs(q);
        
        if (querySnapshot.empty) {
          setError('Link not found');
          setLoading(false);
          return;
        }
        
        const linkDoc = querySnapshot.docs[0];
        const link = { id: linkDoc.id, ...linkDoc.data() };
        
        // Check if the link belongs to the current user
        if (link.userId !== currentUser.uid) {
          setError('You do not have access to this link');
          setLoading(false);
          return;
        }
        
        setLinkData(link);
        
        // Then, get all visits for this link
        const visitsRef = collection(db, 'visits');
        const visitsQuery = query(visitsRef, where('trackingId', '==', linkId));
        const visitsSnapshot = await getDocs(visitsQuery);
        
        const visitsData = [];
        visitsSnapshot.forEach(doc => {
          visitsData.push({ 
            id: doc.id,
            ...doc.data(),
            timestamp: doc.data().timestamp?.toDate() || new Date()
          });
        });
        
        // Sort visits by timestamp
        visitsData.sort((a, b) => b.timestamp - a.timestamp);
        
        setVisits(visitsData);
      } catch (err) {
        console.error('Error fetching link details:', err);
        setError('Failed to load link details');
      } finally {
        setLoading(false);
      }
    };
    
    fetchLinkData();
  }, [linkId, currentUser]);
  
  const copyTrackingLink = () => {
    const baseUrl = window.location.origin;
    const trackingUrl = `${baseUrl}/track/${linkData.trackingType}/${linkData.trackingId}`;
    
    navigator.clipboard.writeText(trackingUrl)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
      })
      .catch(err => {
        console.error('Failed to copy:', err);
      });
  };
  
  // Format date for display
  const formatDate = (date) => {
    return new Date(date).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Prepare data for charts
  const prepareVisitsByDayChart = () => {
    const visitsByDay = {};
    
    visits.forEach(visit => {
      const day = new Date(visit.timestamp).toISOString().split('T')[0];
      
      if (!visitsByDay[day]) {
        visitsByDay[day] = {
          date: day,
          visits: 1
        };
      } else {
        visitsByDay[day].visits += 1;
      }
    });
    
    return Object.values(visitsByDay).sort((a, b) => a.date.localeCompare(b.date));
  };
  
  const prepareDeviceChart = () => {
    const devices = {};
    
    visits.forEach(visit => {
      const device = visit.deviceType || 'Unknown';
      
      if (!devices[device]) {
        devices[device] = {
          name: device,
          value: 1
        };
      } else {
        devices[device].value += 1;
      }
    });
    
    return Object.values(devices);
  };

  const prepareBrowserChart = () => {
    const browsers = {};
    
    visits.forEach(visit => {
      const browser = visit.browser || 'Unknown';
      
      if (!browsers[browser]) {
        browsers[browser] = {
          name: browser,
          value: 1
        };
      } else {
        browsers[browser].value += 1;
      }
    });
    
    return Object.values(browsers);
  };
  
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-sm">
        <div className="p-4 bg-red-50 rounded-md mb-6">
          <p className="text-red-800">{error}</p>
        </div>
        <button
          onClick={() => navigate('/dashboard')}
          className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  if (!linkData) {
    return (
      <div className="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-sm">
        <div className="p-4 bg-yellow-50 rounded-md mb-6">
          <p className="text-yellow-800">Link not found</p>
        </div>
        <button
          onClick={() => navigate('/dashboard')}
          className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  const visitsByDayData = prepareVisitsByDayChart();
  const deviceData = prepareDeviceChart();
  const browserData = prepareBrowserChart();
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-gray-800">Link Details</h1>
          <button
            onClick={() => navigate('/dashboard')}
            className="text-blue-600 hover:text-blue-800"
          >
            Back to Dashboard
          </button>
        </div>
        
        <div className="mb-8 p-4 bg-gray-50 rounded-md">
          <div className="flex flex-col md:flex-row justify-between mb-4">
            <div>
              <h2 className="text-lg font-medium text-gray-800">Original URL</h2>
              <a 
                href={linkData.originalUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline break-all"
              >
                {linkData.originalUrl}
              </a>
            </div>
            
            <div className="mt-4 md:mt-0 text-right">
              <p className="text-sm text-gray-500">Created on</p>
              <p className="text-gray-800">
                {linkData.createdAt?.toDate ? 
                  formatDate(linkData.createdAt.toDate()) : 
                  'Unknown date'
                }
              </p>
            </div>
          </div>
          
          <div className="mt-4">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Tracking Link</h3>
            <div className="flex">
              <input
                type="text"
                value={`${window.location.origin}/track/${linkData.trackingType}/${linkData.trackingId}`}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md bg-gray-100 text-sm focus:outline-none"
              />
              <button
                onClick={copyTrackingLink}
                className={`px-4 py-2 rounded-r-md text-sm focus:outline-none ${
                  copied
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                }`}
              >
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
            <div className="bg-blue-50 p-4 rounded-md">
              <p className="text-sm font-medium text-blue-800 mb-1">Total Clicks</p>
              <p className="text-3xl font-bold text-blue-900">{linkData.clickCount || 0}</p>
            </div>
            
            <div className="bg-green-50 p-4 rounded-md">
              <p className="text-sm font-medium text-green-800 mb-1">Unique Visitors</p>
              <p className="text-3xl font-bold text-green-900">
                {Array.from(new Set(visits.map(v => v.visitorId))).length}
              </p>
            </div>
            
            <div className="bg-purple-50 p-4 rounded-md">
              <p className="text-sm font-medium text-purple-800 mb-1">Tracking Type</p>
              <p className="text-xl font-bold text-purple-900">
                {linkData.trackingType === 'cloudflare' ? 'Standard Redirect' : 'Custom View'}
              </p>
            </div>
          </div>
        </div>
        
        {visits.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-lg">
            <p className="text-gray-500">No clicks recorded yet for this link.</p>
            <button
              onClick={copyTrackingLink}
              className="mt-4 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Copy Link to Share
            </button>
          </div>
        ) : (
          <>
            <div className="mb-8">
              <h2 className="text-lg font-medium text-gray-800 mb-4">Clicks Over Time</h2>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={visitsByDayData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="visits" stroke="#3b82f6" name="Clicks" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div>
                <h2 className="text-lg font-medium text-gray-800 mb-4">Devices</h2>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={deviceData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {deviceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              <div>
                <h2 className="text-lg font-medium text-gray-800 mb-4">Browsers</h2>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={browserData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" name="Clicks" fill="#8884d8">
                        {browserData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-lg font-medium text-gray-800 mb-4">Recent Visits</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Time
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Device
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Browser
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Location
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Referrer
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {visits.slice(0, 10).map((visit) => (
                      <tr key={visit.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDate(visit.timestamp)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {visit.deviceType || 'Unknown'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {visit.browser || 'Unknown'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {visit.location || 'Unknown'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 max-w-xs truncate">
                          {visit.referrer || 'Direct'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default LinkDetail;