import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { collection, query, where, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { useAuth } from '../../context/AuthContext';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Dashboard = () => {
  const { currentUser } = useAuth();
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    const fetchLinks = async () => {
      try {
        if (!currentUser) return;

        const linksRef = collection(db, 'links');
        const q = query(
          linksRef, 
          where('userId', '==', currentUser.uid),
          orderBy('createdAt', 'desc')
        );
        
        const querySnapshot = await getDocs(q);
        const fetchedLinks = [];
        
        querySnapshot.forEach((doc) => {
          fetchedLinks.push({
            id: doc.id,
            ...doc.data(),
            createdAt: doc.data().createdAt?.toDate() || new Date()
          });
        });
        
        setLinks(fetchedLinks);
        
        // Process data for chart
        processChartData(fetchedLinks);
      } catch (err) {
        console.error('Error fetching links:', err);
        setError('Failed to load your tracking links');
      } finally {
        setLoading(false);
      }
    };
    
    fetchLinks();
  }, [currentUser]);
  
  // Process link data for charts
  const processChartData = (linkData) => {
    if (!linkData.length) return;
    
    // Group links by creation date
    const linksByDate = linkData.reduce((acc, link) => {
      const date = new Date(link.createdAt).toISOString().split('T')[0];
      
      if (!acc[date]) {
        acc[date] = {
          date,
          links: 1,
          clicks: link.clickCount || 0
        };
      } else {
        acc[date].links += 1;
        acc[date].clicks += (link.clickCount || 0);
      }
      
      return acc;
    }, {});
    
    // Convert to array and sort by date
    const chartData = Object.values(linksByDate)
      .sort((a, b) => a.date.localeCompare(b.date));
    
    setChartData(chartData);
  };
  
  // Format date for display
  const formatDate = (date) => {
    return new Date(date).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Helper function to truncate long URLs
  const truncateUrl = (url, maxLength = 50) => {
    if (!url) return '';
    if (url.length <= maxLength) return url;
    return `${url.substring(0, maxLength)}...`;
  };
  
  // Calculate total clicks
  const totalClicks = links.reduce((sum, link) => sum + (link.clickCount || 0), 0);
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h1 className="text-2xl font-semibold text-gray-800 mb-4">Your Dashboard</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-blue-50 p-6 rounded-lg">
            <p className="text-sm font-medium text-blue-800 mb-1">Total Links</p>
            <p className="text-3xl font-bold text-blue-900">{links.length}</p>
          </div>
          
          <div className="bg-green-50 p-6 rounded-lg">
            <p className="text-sm font-medium text-green-800 mb-1">Total Clicks</p>
            <p className="text-3xl font-bold text-green-900">{totalClicks}</p>
          </div>
          
          <div className="bg-purple-50 p-6 rounded-lg">
            <p className="text-sm font-medium text-purple-800 mb-1">Avg. Clicks per Link</p>
            <p className="text-3xl font-bold text-purple-900">
              {links.length ? (totalClicks / links.length).toFixed(1) : 0}
            </p>
          </div>
        </div>
        
        <div className="flex justify-end mb-4">
          <Link
            to="/create"
            className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Create New Link
          </Link>
        </div>
        
        {chartData.length > 0 && (
          <div className="h-72 mb-8">
            <h2 className="text-lg font-medium text-gray-800 mb-4">Link Activity</h2>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="links" stroke="#3b82f6" name="Links Created" />
                <Line type="monotone" dataKey="clicks" stroke="#10b981" name="Total Clicks" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        
        {links.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-lg">
            <p className="text-gray-500 mb-4">You haven't created any tracking links yet.</p>
            <Link
              to="/create"
              className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Create Your First Link
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Original URL
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Created
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Clicks
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {links.map((link) => (
                  <tr key={link.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <a 
                        href={link.originalUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:underline"
                      >
                        {truncateUrl(link.originalUrl)}
                      </a>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(link.createdAt)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {link.clickCount || 0}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {link.trackingType === 'cloudflare' ? 'Standard' : 'Custom View'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <Link
                        to={`/results/${link.trackingId}`}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        View Results
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;