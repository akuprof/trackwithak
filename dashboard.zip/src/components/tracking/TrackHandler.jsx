import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { collection, query, where, getDocs, updateDoc, increment, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase/config';

// Helper function to detect browser
const detectBrowser = () => {
  const userAgent = navigator.userAgent;
  
  if (userAgent.indexOf("Chrome") > -1) return "Chrome";
  if (userAgent.indexOf("Safari") > -1) return "Safari";
  if (userAgent.indexOf("Firefox") > -1) return "Firefox";
  if (userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("Trident") > -1) return "Internet Explorer";
  if (userAgent.indexOf("Edge") > -1) return "Edge";
  if (userAgent.indexOf("Opera") > -1) return "Opera";
  
  return "Unknown";
};

// Helper function to detect device type
const detectDeviceType = () => {
  const userAgent = navigator.userAgent;
  
  if (/iPad|iPhone|iPod/.test(userAgent)) return "iOS";
  if (/Android/.test(userAgent)) return "Android";
  if (/Windows Phone/.test(userAgent)) return "Windows Phone";
  if (/Windows/.test(userAgent)) return "Windows";
  if (/Macintosh|MacIntel|MacPPC|Mac68K/.test(userAgent)) return "Mac";
  if (/Linux/.test(userAgent)) return "Linux";
  
  return "Unknown";
};

const TrackHandler = () => {
  const { trackingType, trackingId } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [linkData, setLinkData] = useState(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    const processTracking = async () => {
      try {
        if (!trackingId) {
          setError('Invalid tracking link');
          return;
        }
        
        // Find the link in the database
        const linksRef = collection(db, 'links');
        const q = query(linksRef, where('trackingId', '==', trackingId));
        const querySnapshot = await getDocs(q);
        
        if (querySnapshot.empty) {
          setError('Link not found');
          return;
        }
        
        const linkDoc = querySnapshot.docs[0];
        const link = { id: linkDoc.id, ...linkDoc.data() };
        setLinkData(link);
        
        // Generate a visitor ID if none exists (using session storage to count unique visits)
        const visitorId = sessionStorage.getItem('visitorId') || 
          Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        sessionStorage.setItem('visitorId', visitorId);
        
        // Record the visit
        await addDoc(collection(db, 'visits'), {
          trackingId,
          linkId: linkDoc.id,
          userId: link.userId,
          timestamp: serverTimestamp(),
          visitorId,
          browser: detectBrowser(),
          deviceType: detectDeviceType(),
          referrer: document.referrer || null,
          location: null, // Could integrate with a geolocation API in the future
        });
        
        // Increment click count on the link
        await updateDoc(linkDoc.ref, {
          clickCount: increment(1)
        });
        
        // If this is a standard redirect (cloudflare type), redirect immediately
        if (trackingType === 'cloudflare') {
          window.location.href = link.originalUrl;
        }
        // Otherwise show the branded redirect page for a moment before redirecting
        
      } catch (err) {
        console.error('Error processing tracking link:', err);
        setError('Failed to process this tracking link');
      } finally {
        setLoading(false);
      }
    };
    
    processTracking();
  }, [trackingId, trackingType]);

  // For custom view tracking type, redirect after a delay
  useEffect(() => {
    let redirectTimer;
    
    if (!loading && linkData && trackingType === 'webview') {
      redirectTimer = setTimeout(() => {
        window.location.href = linkData.originalUrl;
      }, 3000); // 3-second delay for the branded page
    }
    
    return () => {
      if (redirectTimer) clearTimeout(redirectTimer);
    };
  }, [loading, linkData, trackingType]);

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gray-50">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-blue-500 border-t-transparent mb-4"></div>
        <h2 className="text-xl font-medium text-gray-700">Processing your link...</h2>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gray-50 p-6">
        <div className="p-6 bg-white rounded-lg shadow-md max-w-md w-full">
          <h2 className="text-xl font-medium text-red-600 mb-4">Link Error</h2>
          <p className="text-gray-700 mb-6">{error}</p>
          <button
            onClick={() => navigate('/')}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Go to Homepage
          </button>
        </div>
      </div>
    );
  }

  // Custom view with branding for the webview tracking type
  if (trackingType === 'webview' && linkData) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gray-50 p-6">
        <div className="p-6 bg-white rounded-lg shadow-md max-w-md w-full text-center">
          <h2 className="text-2xl font-bold text-blue-600 mb-2">Link Tracker</h2>
          <p className="text-gray-700 mb-6">You are being redirected to:</p>
          
          <div className="p-4 bg-gray-50 rounded-md mb-6">
            <p className="font-medium text-blue-600 break-all">
              {linkData.originalUrl}
            </p>
          </div>
          
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="h-2 w-2 bg-blue-600 rounded-full animate-pulse"></div>
            <div className="h-2 w-2 bg-blue-600 rounded-full animate-pulse delay-150"></div>
            <div className="h-2 w-2 bg-blue-600 rounded-full animate-pulse delay-300"></div>
          </div>
          
          <p className="text-sm text-gray-500">Redirecting you automatically in a moment...</p>
          
          <div className="mt-6">
            <a
              href={linkData.originalUrl}
              className="inline-block bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Continue Now
            </a>
          </div>
        </div>
      </div>
    );
  }

  // Fallback for cloudflare type (should have redirected already)
  return (
    <div className="flex flex-col justify-center items-center min-h-screen bg-gray-50 p-6">
      <div className="p-6 bg-white rounded-lg shadow-md max-w-md w-full text-center">
        <h2 className="text-xl font-medium text-gray-700 mb-4">Redirecting...</h2>
        <p className="text-gray-600 mb-6">
          If you are not redirected automatically, please click the button below.
        </p>
        <a
          href={linkData?.originalUrl}
          className="inline-block bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          Continue to Website
        </a>
      </div>
    </div>
  );
};

export default TrackHandler;