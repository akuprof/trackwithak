import React, { createContext, useState, useContext, useEffect } from 'react';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged 
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase/config';

// Create the authentication context
const AuthContext = createContext();

// Custom hook to use the authentication context
export function useAuth() {
  return useContext(AuthContext);
}

// Authentication provider component
export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const auth = getAuth();
  
  // Register new user
  const register = async (email, password, fullName) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Create a user document in Firestore
    await setDoc(doc(db, 'users', user.uid), {
      fullName,
      email,
      createdAt: new Date(),
      subscriptionTier: 'Free', // Default to free tier
      linksLimit: 10, // Default limit for free tier
      linksCreated: 0,
      lastLogin: new Date()
    });
    
    return user;
  };
  
  // Login existing user
  const login = (email, password) => {
    return signInWithEmailAndPassword(auth, email, password);
  };
  
  // Logout current user
  const logout = () => {
    return signOut(auth);
  };
  
  // Update user's last login timestamp
  const updateLastLogin = async (userId) => {
    const userRef = doc(db, 'users', userId);
    await setDoc(userRef, {
      lastLogin: new Date()
    }, { merge: true });
  };
  
  // Fetch user data from Firestore
  const fetchUserData = async (userId) => {
    try {
      const userDoc = await getDoc(doc(db, 'users', userId));
      if (userDoc.exists()) {
        return userDoc.data();
      }
      return null;
    } catch (error) {
      console.error('Error fetching user data:', error);
      return null;
    }
  };
  
  // Setup auth state listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      
      // If user is logged in, fetch their data from Firestore
      if (user) {
        try {
          // Update last login time
          await updateLastLogin(user.uid);
          
          // Get user data
          const data = await fetchUserData(user.uid);
          setUserData(data);
        } catch (error) {
          console.error('Error in auth state change:', error);
        }
      } else {
        setUserData(null);
      }
      
      setLoading(false);
    });
    
    return unsubscribe;
  }, []);
  
  // Context value
  const value = {
    currentUser,
    userData,
    loading,
    register,
    login,
    logout
  };
  
  return (
    <AuthContext.Provider value={value}>
      {!loading ? children : (
        <div className="flex justify-center items-center h-screen">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
        </div>
      )}
    </AuthContext.Provider>
  );
}